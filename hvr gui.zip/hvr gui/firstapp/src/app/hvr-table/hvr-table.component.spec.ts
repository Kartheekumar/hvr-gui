import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HvrTableComponent } from './hvr-table.component';

describe('HvrTableComponent', () => {
  let component: HvrTableComponent;
  let fixture: ComponentFixture<HvrTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HvrTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HvrTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
