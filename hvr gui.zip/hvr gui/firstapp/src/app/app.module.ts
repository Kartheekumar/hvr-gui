import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SchedulerComponent } from './scheduler/scheduler.component';
import { HvrTableComponent } from './hvr-table/hvr-table.component';
import { TableBasicExampleComponent } from './table-basic-example/table-basic-example.component';
import { AgGridExampleComponent } from './ag-grid-example/ag-grid-example.component';
import { AgGridModule } from 'ag-grid-angular';
import { HttpClientModule } from '@angular/common/http';



@NgModule({
  declarations: [
    AppComponent,
    SchedulerComponent,
    HvrTableComponent,
    AgGridExampleComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    AgGridModule.withComponents([]),
    
  ],
  providers: [],
  bootstrap: [AppComponent,SchedulerComponent,AgGridExampleComponent]
})
export class AppModule { }
