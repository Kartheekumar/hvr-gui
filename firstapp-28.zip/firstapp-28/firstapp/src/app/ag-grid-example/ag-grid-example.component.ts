import { Component,OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-ag-grid-example',
  templateUrl: './ag-grid-example.component.html',
  styleUrls: ['./ag-grid-example.component.css']
})
export class AgGridExampleComponent {

  title = 'app';



columnDefs = [
  {headerName: 'System_name', field: 'system_name', sortable: true, filter: true},
  {headerName: 'Job_type', field: 'job_type', sortable: true, filter: true},
  {headerName: 'Job_name', field: 'job_name', sortable: true, filter: true},
  {headerName: 'Job_state', field: 'job_state', sortable: true, filter: true,cellStyle: function(params) {
    if (params.value=='RUNNING') {
        //mark police cells as red
        return { backgroundColor: 'green'};
    }
    else if(params.value=='PENDING'){
      return {backgroundColor:'green'}
    }
    else if(params.value=='SUSPEND'){
      return {backgroundColor:'orange'}
    }
    else if(params.value=='FINISH'){
      return {backgroundColor:'green'}
    }
     else 
     {
        return {backgroundColor:'red'};
    }
    
}},
  {headerName: 'Job_last_run_begin', field: 'job_last_run_begin', sortable: true, filter: true},
  {headerName: 'Job_last_run_end', field: 'job_last_run_end', sortable: true, filter: true}

];



rowData: any;
constructor(private http: HttpClient) {

}

ngOnInit() {
    this.rowData = this.http.get('http://3.251.13.183:8080/v1/getHvrStatus');
}
}

