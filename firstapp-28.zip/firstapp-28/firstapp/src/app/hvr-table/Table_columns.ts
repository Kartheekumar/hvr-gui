export class Table_columns{
    System_Name:string;
    Job_Name:string;
    Status:string;
    Last_Start_time:string;
    Last_End_time:string;
    No_of_Retries:string;
    Log:string;
  }
  